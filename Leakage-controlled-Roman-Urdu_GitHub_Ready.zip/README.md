# Leakage-controlled Roman Urdu-English Sentiment Study

This repository is a sanitized reproducibility release for the Phase 10P model-comparison study. It contains the approved development splits, the researcher-authorized 315-record human-gold test release, reproducibility code, aggregate results, sanitized predictions, result figures, and checksums. It does not contain reviewer workbooks, private adjudication notes, credentials, or raw API response bodies.

## Scientific populations

- Development: 10,135 usable source-derived/weak-label records; 8,108 training and 2,027 validation records. These are not human-gold labels.
- Human-gold test release: 315 records; 146 Negative, 41 Neutral, and 128 Positive. The researcher confirmed permission to publish the study dataset; source-specific licensing and provider-term checks remain an author release gate.
- The populations are separate. Protected labels and review text are not included in this public release.

## Results

The released aggregate results correspond to the sealed Phase 10P evaluation. The four LLM conditions were recovered deterministically from the original concurrent ledger by selecting the first recorded response for each record-condition-model key. This is not claimed to be the first network request. The original ledger contained 2,069 attempts, 1,260 unique keys, and 809 additional attempts.

## Reproduction limits

The public package can inspect the released development splits, reproduce offline audits, and inspect sanitized predictions and aggregate results. Reproducing the hosted-model requests requires authorized access to the CGU local-model endpoint. No API key, reviewer workbook, or raw response body is included.

## Offline commands

Run from this repository root with Python 3.10+:

```powershell
python code/phase10_offline/01_audit_sources.py --input-dir path/to/permitted/data --output tmp/source_inventory.json
python code/phase10_offline/02_clean_deduplicate.py --input path/to/permitted.csv --output tmp/clean.csv --audit tmp/clean_audit.json
python code/phase10_offline/03_validate_labels.py --input tmp/clean.csv --output tmp/label_audit.json
python code/phase10_offline/04_build_splits.py --input tmp/clean.csv --output-dir tmp/splits
python code/phase10_offline/05_train_tfidf.py --train tmp/splits/train.csv --validation tmp/splits/validation.csv --output-dir tmp/tfidf
python code/phase10_offline/06_prepare_frozen_prompts.py --input tmp/splits/train.csv --output tmp/prompt_config.json
```

The generic LLM and scoring scripts are guarded examples requiring explicit authorized inputs and flags. The Phase 10P recovery/scoring scripts are included for provenance but require the original restricted project layout; they must not be pointed at public substitutes.

## Contents

- `code/`: offline preparation, guarded inference/scoring examples, Phase 10P recovery/scoring, and release sanitization.
- `configs/`: non-secret frozen settings and hashes.
- `data/development/`: 10,135 source-derived/weak-label development records split into training and validation files.
- `data/human_gold/`: researcher-authorized 315-record human-gold release with only publication-approved fields.
- `data/metadata/`: counts, provenance, and ID/hash-only manifest.
- `results/`: aggregate metrics, class results, confusion matrices, statistical analysis, and sanitized predictions.
- `figures/`: five publication figures in PNG and SVG formats.
- `docs/`: data dictionary, permission audit, and reproduction notes.

## License and access

No blanket license is asserted for source review text or protected annotations. The author has confirmed permission for this study release, but source-specific license and provider-term verification must be completed before public upload. See `docs/PUBLIC_DATA_PERMISSION_AUDIT.md` and `LICENSE`.
