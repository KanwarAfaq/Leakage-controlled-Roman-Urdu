# Phase 10P usage and coverage

Gold-test size: 315 records — Negative 146, Neutral 41, Positive 128.

| Condition | Valid coverage | Invalid | Mean latency (s) | Median latency (s) | Mean prompt tokens | Mean completion tokens | Mean total tokens |
|---|---:|---:|---:|---:|---:|---:|---:|
| TF-IDF | 100.00% | 0 | — | — | — | — | — |
| GPT-OSS zero-shot | 89.84% | 32 | 27.933 | 21.057 | 139.87 | 110.29 | 250.16 |
| GPT-OSS few-shot | 97.46% | 8 | 30.945 | 35.629 | 439.00 | 157.42 | 596.42 |
| Gemma zero-shot | 99.68% | 1 | 0.635 | 0.441 | 86.00 | 2.00 | 88.00 |
| Gemma few-shot | 99.68% | 1 | 0.503 | 0.384 | 377.09 | 2.00 | 379.09 |

Invalid outputs were retained from the selected first-recorded responses. GPT-OSS zero-shot had 32 invalid outputs, GPT-OSS few-shot 8, Gemma zero-shot 1, and Gemma few-shot 1. Invalid outputs count as incorrect in primary all-request metrics. The latency and token values are gateway-recorded usage metadata, not energy or monetary-cost measurements.
