# Phase 10P statistical analysis

Gold scoring was performed only after the 1,575-row prediction seal passed. Invalid outputs were counted as incorrect in the primary all-request metrics. Confusion matrices use valid parsed outputs only; valid-only metrics are secondary.

## Bootstrap
Paired bootstrap confidence intervals used 10,000 resamples of the 315 identical IDs with seed 20261025. Macro-F1 and accuracy intervals are percentile intervals. Pairwise macro-F1 differences are descriptive.

## Paired accuracy tests
Exact two-sided McNemar tests were computed for TF-IDF versus each LLM condition and for zero-shot versus few-shot within GPT-OSS and Gemma. These are prespecified descriptive comparisons; no multiplicity-adjusted universal superiority claim is made.

- tfidf_logistic_regression vs gemma_few_shot: discordances 10 vs 112; exact McNemar p=5.68196e-23; macro-F1 difference=-0.327102 (bootstrap 95% CI -0.388604, -0.263833).
- tfidf_logistic_regression vs gemma_zero_shot: discordances 17 vs 116; exact McNemar p=2.64324e-19; macro-F1 difference=-0.302951 (bootstrap 95% CI -0.372138, -0.231293).
- tfidf_logistic_regression vs gpt_oss_few_shot: discordances 19 vs 100; exact McNemar p=1.81424e-14; macro-F1 difference=-0.267530 (bootstrap 95% CI -0.331830, -0.203762).
- tfidf_logistic_regression vs gpt_oss_zero_shot: discordances 35 vs 101; exact McNemar p=1.30042e-08; macro-F1 difference=-0.242654 (bootstrap 95% CI -0.314355, -0.166369).
- gpt_oss_zero_shot vs gpt_oss_few_shot: discordances 17 vs 32; exact McNemar p=0.0443842; macro-F1 difference=-0.024875 (bootstrap 95% CI -0.074999, 0.025026).
- gemma_zero_shot vs gemma_few_shot: discordances 10 vs 13; exact McNemar p=0.677639; macro-F1 difference=-0.024151 (bootstrap 95% CI -0.070061, 0.020048).
