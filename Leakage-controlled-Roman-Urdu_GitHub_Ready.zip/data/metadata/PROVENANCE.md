# Provenance

The development population is derived from the Phase 10B candidate and Phase 10J development artifacts. Its source labels and weak labels are not human-gold. The Phase 10P test population is represented publicly only by candidate IDs and text hashes; its review text and protected labels remain outside this release pending permission review.

The five-condition results are copied from the sealed Phase 10P evidence artifacts. No historical 237-record result was reassigned to the 315-record test.
