# Licensing notice

This release does not assert redistribution rights for the underlying review texts, protected human-gold labels, reviewer workbooks, or raw model logs. The authors must confirm source-dataset licenses, provider terms, annotation permissions, and any institutional restrictions before adding those materials.

The repository code has no finalized open-source license in this package. The authors should select and add an appropriate code license before public release. Until then, treat the code as all-rights-reserved.
