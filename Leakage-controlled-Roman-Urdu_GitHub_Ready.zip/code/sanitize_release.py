"""Create the conservative public release from local evidence.

The script deliberately removes review text, protected labels, raw responses,
reasoning, request identifiers, and other restricted fields. It does not
re-score or alter scientific evidence.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
from pathlib import Path


def read_csv(path: Path):
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def write_csv(path: Path, rows, fields):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sealed", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    sealed = read_csv(args.sealed)
    manifest = read_csv(args.manifest)
    safe_fields = [
        "record_id", "condition", "model", "parsed_label", "valid",
        "latency_seconds", "prompt_tokens", "completion_tokens",
        "total_tokens", "source", "ledger_line", "timestamp_utc",
        "status_code", "finish_reason", "error", "selection_rule",
    ]
    safe_rows = [{field: row.get(field, "") for field in safe_fields} for row in sealed]
    write_csv(args.output / "Phase10P_Sealed_Predictions_Sanitized.csv", safe_rows, safe_fields)

    manifest_fields = ["candidate_id", "text_sha256"]
    write_csv(
        args.output / "Phase10P_Label_Free_ID_Hash_Manifest.csv",
        [{field: row.get(field, "") for field in manifest_fields} for row in manifest],
        manifest_fields,
    )
    (args.output / "PUBLIC_RELEASE_NOTICE.txt").write_text(
        "Review text and protected gold labels are intentionally withheld pending permissions.\n"
        "The ID/hash manifest is not a substitute for the protected test data.\n",
        encoding="utf-8",
    )
    print({
        "sealed_rows": len(safe_rows),
        "manifest_rows": len(manifest),
        "sealed_sha256": sha256(args.output / "Phase10P_Sealed_Predictions_Sanitized.csv"),
    })


if __name__ == "__main__":
    main()
