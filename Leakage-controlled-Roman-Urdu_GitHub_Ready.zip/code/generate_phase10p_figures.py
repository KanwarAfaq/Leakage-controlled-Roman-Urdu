"""Generate Phase 10P result figures from verified metrics only."""
import csv
import os
from pathlib import Path
os.environ.setdefault("MPLCONFIGDIR", str(Path(__file__).resolve().parent / "mplconfig"))
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[3]
METRICS = ROOT / "Evidence/Phase10P_Final_Recovered_Experiment/Phase10P_Final_Metrics.csv"
PER_CLASS = ROOT / "Evidence/Phase10P_Final_Recovered_Experiment/Phase10P_Per_Class_Results.csv"
OUT = ROOT / "Manuscript/Phase10_Overleaf_Ready/figures"
OUT.mkdir(parents=True, exist_ok=True)

with METRICS.open(encoding="utf-8-sig", newline="") as f:
    metrics = list(csv.DictReader(f))
order = ["tfidf_logistic_regression", "gpt_oss_zero_shot", "gpt_oss_few_shot", "gemma_zero_shot", "gemma_few_shot"]
labels = ["TF-IDF", "GPT-OSS\nzero-shot", "GPT-OSS\nfew-shot", "Gemma\nzero-shot", "Gemma\nfew-shot"]
by = {r["condition"]: r for r in metrics}
colors = ["#4C78A8", "#F58518", "#E45756", "#54A24B", "#B279A2"]

fig, ax = plt.subplots(figsize=(7.2, 4.2), dpi=300)
x = np.arange(5); w = 0.36
acc = [float(by[c]["accuracy_all_requests"]) for c in order]
f1 = [float(by[c]["macro_f1_all_requests"]) for c in order]
ax.bar(x-w/2, acc, w, label="Accuracy", color="#4C78A8")
ax.bar(x+w/2, f1, w, label="Macro-F1", color="#F58518")
ax.set_ylim(0, 1); ax.set_ylabel("Score"); ax.set_xticks(x, labels); ax.grid(axis="y", alpha=.25); ax.legend(frameon=False, ncol=2)
ax.set_title("All-request performance on the 315-record test")
fig.tight_layout(); fig.savefig(OUT / "Figure3_All_Request_Performance.png", dpi=300); fig.savefig(OUT / "Figure3_All_Request_Performance.svg"); plt.close(fig)

with PER_CLASS.open(encoding="utf-8-sig", newline="") as f:
    pc = [r for r in csv.DictReader(f) if r["scope"] == "all_requests_primary"]
pc_by = {(r["condition"], r["class"]): float(r["f1"]) for r in pc}
fig, ax = plt.subplots(figsize=(7.2, 4.2), dpi=300)
w = .16
for i, (c, lab, color) in enumerate(zip(order, labels, colors)):
    ax.bar(np.arange(3) + (i-2)*w, [pc_by[(c, k)] for k in ("negative", "neutral", "positive")], w, label=lab.replace("\n", " "), color=color)
ax.set_ylim(0, 1); ax.set_ylabel("F1"); ax.set_xticks(np.arange(3), ["Negative", "Neutral (n=41)", "Positive"]); ax.grid(axis="y", alpha=.25); ax.legend(frameon=False, fontsize=8, ncol=2)
ax.set_title("Per-class F1 on the 315-record test")
fig.tight_layout(); fig.savefig(OUT / "Figure4_Per_Class_F1.png", dpi=300); fig.savefig(OUT / "Figure4_Per_Class_F1.svg"); plt.close(fig)

coverage = [float(by[c]["valid_output_coverage"]) for c in order]
invalid = [int(by[c]["invalid_count"]) for c in order]
fig, ax = plt.subplots(figsize=(7.2, 4.2), dpi=300)
bars = ax.bar(np.arange(5), coverage, color=colors)
ax.set_ylim(0, 1.12); ax.set_ylabel("Valid-output coverage"); ax.set_xticks(np.arange(5), labels); ax.set_yticks(np.arange(0, 1.01, .2)); ax.set_yticklabels([f"{v:.0%}" for v in np.arange(0, 1.01, .2)]); ax.grid(axis="y", alpha=.25)
for b, cov, inv in zip(bars, coverage, invalid):
    ax.text(b.get_x()+b.get_width()/2, cov+0.035, f"{cov:.1%}\ninvalid={inv}", ha="center", va="bottom", fontsize=8)
ax.set_title("Valid-output coverage and invalid outcomes")
fig.tight_layout(); fig.savefig(OUT / "Figure5_Valid_Output_Coverage.png", dpi=300); fig.savefig(OUT / "Figure5_Valid_Output_Coverage.svg"); plt.close(fig)

print("Generated Figures 3-5")
