"""Regenerate the two methodology figures for the recovered Phase 10P study.

This is a presentation-only script. It reads no protected labels and performs
no inference, scoring, or model fitting.
"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle

ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / "Manuscript" / "Phase10_Overleaf_Ready" / "figures"
OUT.mkdir(parents=True, exist_ok=True)

NAVY = "#1F4E79"
TEAL = "#2A9D8F"
PURPLE = "#6A4C93"
ORANGE = "#E07A2D"
GOLD = "#D9A441"
INK = "#1F2933"
GREY = "#6B7280"
LIGHT_BLUE = "#E8F1FA"
LIGHT_TEAL = "#E8F5F2"
LIGHT_PURPLE = "#F5F0FA"
LIGHT_ORANGE = "#FFF8EC"


def setup(title, subtitle):
    fig, ax = plt.subplots(figsize=(12, 7), dpi=300)
    ax.set_xlim(0, 12)
    ax.set_ylim(0, 7)
    ax.axis("off")
    ax.text(0.25, 6.75, title, fontsize=18, fontweight="bold", color=NAVY, va="top")
    ax.text(0.25, 6.38, subtitle, fontsize=9.5, color=GREY, va="top")
    return fig, ax


def box(ax, xy, wh, text, face, edge, size=9.5, weight="normal"):
    x, y = xy
    w, h = wh
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.025,rounding_size=0.08",
                                facecolor=face, edgecolor=edge, linewidth=1.5))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", color=INK,
            fontsize=size, fontweight=weight, linespacing=1.25)


def arrow(ax, start, end, color=GREY, lw=1.6):
    ax.add_patch(FancyArrowPatch(start, end, arrowstyle="-|>", mutation_scale=12,
                                 linewidth=lw, color=color, connectionstyle="arc3"))


def save(fig, stem):
    fig.savefig(OUT / f"{stem}.png", dpi=300, bbox_inches="tight", pad_inches=0.08)
    fig.savefig(OUT / f"{stem}.svg", bbox_inches="tight", pad_inches=0.08)
    plt.close(fig)


def figure1():
    fig, ax = setup(
        "Expanded human-gold benchmark construction and controlled evaluation",
        "The prospective 315-record benchmark is separate from the historical 237-record study.",
    )
    # source and verification lane
    box(ax, (0.35, 5.15), (2.0, 0.72), "43,261 original\nsource records", LIGHT_BLUE, NAVY, weight="bold")
    box(ax, (2.75, 5.15), (2.1, 0.72), "38,123 globally\nunique texts", LIGHT_BLUE, NAVY)
    box(ax, (5.25, 5.15), (2.15, 0.72), "Independent A/C\nverification: 540", "#F5EFE5", NAVY)
    box(ax, (7.8, 5.15), (2.0, 0.72), "D adjudication:\n206 disputed", "#F5EFE5", NAVY)
    for a, b in [((2.35, 5.51), (2.75, 5.51)), ((4.85, 5.51), (5.25, 5.51)), ((7.4, 5.51), (7.8, 5.51))]:
        arrow(ax, a, b)

    box(ax, (4.2, 4.0), (2.7, 0.78), "315 eligible strict\ncode-mixed records", LIGHT_TEAL, TEAL, weight="bold")
    arrow(ax, (8.8, 5.15), (5.65, 4.78), ORANGE)
    box(ax, (1.2, 2.75), (3.0, 0.82), "315-record protected\nthree-class gold test", LIGHT_TEAL, TEAL, weight="bold")
    box(ax, (7.8, 2.75), (3.0, 0.82), "Historical 237-record\nbenchmark retained separately", "#F2F2F2", GREY, size=8.8)
    arrow(ax, (4.9, 4.0), (2.7, 3.57), TEAL)
    arrow(ax, (5.95, 4.0), (8.7, 3.57), GREY)

    box(ax, (1.2, 1.45), (3.0, 0.82), "Integrity, leakage checks,\nresearcher approval and freeze", LIGHT_TEAL, TEAL, size=8.8, weight="bold")
    arrow(ax, (2.7, 2.75), (2.7, 2.27), TEAL)
    box(ax, (5.0, 1.45), (3.0, 0.82), "Sealed predictions\n1,575 outcomes | 5 conditions", LIGHT_BLUE, NAVY, size=8.8, weight="bold")
    arrow(ax, (4.2, 1.86), (5.0, 1.86), NAVY)
    box(ax, (8.8, 1.45), (2.5, 0.82), "Read-only human-gold\nscoring", LIGHT_TEAL, TEAL, size=8.8, weight="bold")
    arrow(ax, (8.0, 1.86), (8.8, 1.86), TEAL)

    ax.add_patch(Rectangle((0.35, 0.25), 4.0, 0.82, facecolor=LIGHT_PURPLE, edgecolor=PURPLE, linewidth=1.5))
    ax.text(0.55, 0.9, "SEPARATE DEVELOPMENT BRANCH", color=PURPLE, fontsize=9, fontweight="bold", va="top")
    ax.text(0.55, 0.56, "10,135 usable weak-label records  ->  8,108 train / 2,027 validation", color=INK, fontsize=7.8, va="center")
    ax.text(0.55, 0.35, "No protected gold labels enter development.", color=INK, fontsize=7.8, va="center")
    save(fig, "Figure1_Methodology")


def figure2():
    fig, ax = setup(
        "Leakage-controlled model comparison framework",
        "The same 315 label-free inputs branch in parallel; protected labels enter only read-only scoring.",
    )
    # development block
    ax.add_patch(Rectangle((0.25, 4.85), 3.4, 1.25, facecolor=LIGHT_PURPLE, edgecolor=PURPLE, linewidth=1.5))
    ax.text(0.45, 5.88, "DEVELOPMENT ONLY", color=PURPLE, fontsize=10, fontweight="bold", va="top")
    box(ax, (0.5, 5.2), (1.25, 0.42), "8,108 train", "#F3EFFA", PURPLE, size=8.3)
    box(ax, (2.0, 5.2), (1.25, 0.42), "2,027 validation", "#F3EFFA", PURPLE, size=8.3)
    box(ax, (1.05, 4.95), (1.8, 0.35), "Frozen TF-IDF + prompts", "#F3EFFA", PURPLE, size=7.8, weight="bold")
    arrow(ax, (1.12, 5.2), (1.5, 5.3), PURPLE)
    arrow(ax, (2.62, 5.2), (2.4, 5.3), PURPLE)

    # parallel evaluation block
    ax.add_patch(Rectangle((0.25, 1.25), 6.1, 3.2, facecolor="#F7FBFC", edgecolor=TEAL, linewidth=1.5))
    ax.text(0.45, 4.18, "PARALLEL EVALUATION CONDITIONS", color=TEAL, fontsize=10, fontweight="bold", va="top")
    box(ax, (0.65, 3.4), (5.3, 0.5), "Frozen 315-record label-free test input", LIGHT_TEAL, TEAL, size=9, weight="bold")
    names = ["TF-IDF +\nLogistic Regression", "GPT-OSS\nzero-shot", "GPT-OSS\nfew-shot", "Gemma\nzero-shot", "Gemma\nfew-shot"]
    colors = [NAVY, TEAL, ORANGE, PURPLE, GOLD]
    xs = [0.55, 1.75, 2.95, 4.15, 5.35]
    for x, name, color in zip(xs, names, colors):
        box(ax, (x, 2.35), (0.95, 0.62), name, LIGHT_BLUE, color, size=7.4, weight="bold")
        arrow(ax, (x + 0.475, 3.4), (x + 0.475, 2.98), color)
        arrow(ax, (x + 0.475, 2.35), (7.0, 3.22), color)

    # parser/audit/scoring
    ax.add_patch(Rectangle((6.65, 0.95), 2.55, 5.15, facecolor="#F7FAFC", edgecolor=NAVY, linewidth=1.5))
    ax.text(6.85, 5.88, "PARSER / AUDIT / SCORING", color=NAVY, fontsize=9.5, fontweight="bold", va="top")
    box(ax, (6.95, 4.65), (1.95, 0.55), "Strict parser; invalids\npreserved", LIGHT_BLUE, NAVY, size=8.2)
    box(ax, (6.95, 3.75), (1.95, 0.55), "Raw predictions,\nlatency, tokens", LIGHT_BLUE, NAVY, size=8.2)
    box(ax, (6.95, 2.85), (1.95, 0.55), "Prediction sealing\n1,575 outcomes", LIGHT_BLUE, NAVY, size=8.2, weight="bold")
    box(ax, (6.95, 1.95), (1.95, 0.55), "Read-only human-gold\nscoring", LIGHT_TEAL, TEAL, size=8.2, weight="bold")
    box(ax, (6.95, 1.1), (1.95, 0.5), "Metrics, CIs, paired tests,\ncoverage and latency", LIGHT_TEAL, TEAL, size=7.7)
    for y1, y2, color in [(4.65, 4.3, NAVY), (3.75, 3.4, NAVY), (2.85, 2.5, TEAL), (1.95, 1.6, TEAL)]:
        arrow(ax, (7.925, y1), (7.925, y2), color)

    # protected labels, one arrow only to scoring
    ax.add_patch(Rectangle((9.55, 0.95), 2.2, 5.15, facecolor=LIGHT_ORANGE, edgecolor=ORANGE, linewidth=1.5))
    ax.text(9.75, 5.88, "PROTECTED GOLD LABELS", color=ORANGE, fontsize=9.3, fontweight="bold", va="top")
    ax.text(10.65, 4.0, "315 labels\n146 Negative\n41 Neutral\n128 Positive", ha="center", va="center", fontsize=10, fontweight="bold", color=INK, linespacing=1.35)
    ax.text(10.65, 2.0, "Never used for\nmodel fitting, prompts,\ninference, or selection", ha="center", va="center", fontsize=8.3, color=INK, linespacing=1.35)
    arrow(ax, (9.55, 2.22), (8.9, 2.22), ORANGE)
    save(fig, "Figure2_Leakage_Controlled_Framework")


if __name__ == "__main__":
    figure1()
    figure2()
