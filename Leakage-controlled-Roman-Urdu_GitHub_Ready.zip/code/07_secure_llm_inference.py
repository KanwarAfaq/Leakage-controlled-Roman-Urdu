import argparse,json,os,time,urllib.request
def main():
    p=argparse.ArgumentParser(); p.add_argument('--input',required=True); p.add_argument('--config',required=True); p.add_argument('--output',required=True); p.add_argument('--model',required=True); p.add_argument('--endpoint',default=''); p.add_argument('--authorize',action='store_true'); a=p.parse_args()
    if not a.authorize: raise SystemExit('Refusing inference: pass --authorize only after prospective protocol approval')
    key=os.environ.get('CGU_API_KEY')
    if not key or not a.endpoint: raise SystemExit('Provide CGU_API_KEY privately and an authorized --endpoint')
    records=[json.loads(x) for x in open(a.input,encoding='utf-8') if x.strip()]
    with open(a.output,'w',encoding='utf-8') as out:
        for r in records:
            start=time.time(); payload=json.dumps({'model':a.model,'messages':[{'role':'user','content':r['text']}],'temperature':0}).encode(); req=urllib.request.Request(a.endpoint,data=payload,headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'}); err=None; data={}
            try:
                with urllib.request.urlopen(req,timeout=120) as h: data=json.load(h)
            except Exception as e: err=type(e).__name__
            out.write(json.dumps({'record_id':r['record_id'],'model':a.model,'response':data,'error':err,'latency_seconds':time.time()-start})+'\n')
if __name__=='__main__': main()
