"""Deterministic group-aware split. It does not freeze a prospective test set."""
import argparse,csv,hashlib,random
from pathlib import Path
def main():
 p=argparse.ArgumentParser(); p.add_argument('--input',required=True); p.add_argument('--output-dir',required=True); p.add_argument('--group-column',default='split_group_id'); p.add_argument('--seed',type=int,default=20261025); a=p.parse_args()
 with open(a.input,encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
 if not rows: raise SystemExit('Input is empty')
 groups={}
 for r in rows: groups.setdefault(r.get(a.group_column) or r.get('exact_group_id_phase10') or hashlib.sha256(r.get('normalized_text_phase10','').encode()).hexdigest(),[]).append(r)
 keys=list(groups); random.Random(a.seed).shuffle(keys); cuts=[int(.8*len(keys)),int(.9*len(keys))]; Path(a.output_dir).mkdir(parents=True,exist_ok=True)
 for name,ks in [('train',keys[:cuts[0]]),('validation',keys[cuts[0]:cuts[1]]),('test',keys[cuts[1]:])]:
  out=[r for k in ks for r in groups[k]]
  with open(Path(a.output_dir)/(name+'.csv'),'w',encoding='utf-8',newline='') as f: w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(out)
 print({n:sum(len(groups[k]) for k in ks) for n,ks in [('train',keys[:cuts[0]]),('validation',keys[cuts[0]:cuts[1]]),('test',keys[cuts[1]:])]})
if __name__=='__main__': main()
