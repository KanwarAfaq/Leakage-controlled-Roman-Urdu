"""Inventory CSV sources without assigning labels or claiming eligibility."""
import argparse,csv,hashlib,json
from pathlib import Path
def digest(p):
 h=hashlib.sha256(); f=p.open('rb')
 for b in iter(lambda:f.read(1048576),b''): h.update(b)
 return h.hexdigest()
def main():
 p=argparse.ArgumentParser(); p.add_argument('--input-dir',required=True); p.add_argument('--output',required=True); a=p.parse_args(); out=[]
 for f in sorted(Path(a.input_dir).rglob('*.csv')):
  try:
   with f.open(encoding='utf-8-sig',newline='') as h: r=csv.reader(h); cols=next(r,[]); n=sum(1 for _ in r); enc='utf-8-sig'
  except UnicodeDecodeError:
   with f.open(encoding='cp1252',errors='replace',newline='') as h: r=csv.reader(h); cols=next(r,[]); n=sum(1 for _ in r); enc='cp1252-replace'
  out.append({'path':str(f),'rows':n,'columns':cols,'encoding':enc,'sha256':digest(f)})
 Path(a.output).parent.mkdir(parents=True,exist_ok=True); Path(a.output).write_text(json.dumps({'sources':out},indent=2),encoding='utf-8'); print({'files':len(out),'rows':sum(x['rows'] for x in out)})
if __name__=='__main__': main()
