import argparse,csv,json
def main():
    p=argparse.ArgumentParser(); p.add_argument('--predictions',required=True); p.add_argument('--gold',required=True); p.add_argument('--output',required=True); p.add_argument('--score-authorized',action='store_true'); a=p.parse_args()
    if not a.score_authorized: raise SystemExit('Refusing gold access without --score-authorized')
    gold={r['record_id']:r['label'].casefold() for r in csv.DictReader(open(a.gold,encoding='utf-8-sig',newline=''))}; rows=[json.loads(x) for x in open(a.predictions,encoding='utf-8') if x.strip()]; pairs=[]
    for r in rows:
        pred=(r.get('prediction') or '').casefold(); pairs.append((gold.get(r['record_id']),pred if pred in {'negative','neutral','positive'} else None))
    valid=sum(p is not None for _,p in pairs); result={'n':len(pairs),'valid_output_coverage':valid/len(pairs) if pairs else 0,'all_request_accuracy':sum(y==p for y,p in pairs)/len(pairs) if pairs else 0,'valid_predictions':valid}
    open(a.output,'w',encoding='utf-8').write(json.dumps(result,indent=2)); print(result)
if __name__=='__main__': main()
