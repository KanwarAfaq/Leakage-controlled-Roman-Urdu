"""Normalize text and create exact duplicate groups; source labels are unchanged."""
import argparse,csv,hashlib,json,re
from pathlib import Path
def norm(s): return re.sub(r'\s+',' ',(s or '').strip().casefold())
def main():
 p=argparse.ArgumentParser(); p.add_argument('--input',required=True); p.add_argument('--output',required=True); p.add_argument('--audit',required=True); a=p.parse_args()
 with open(a.input,encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
 col=next((x for x in ['normalized_text','Review','review','text'] if rows and x in rows[0]),None)
 if not col: raise SystemExit('No supported review-text column found')
 groups={}
 for r in rows: groups.setdefault(norm(r.get(col,'')),[]).append(r)
 out=[]
 for key,items in sorted(groups.items()):
  r=dict(items[0]); r['normalized_text_phase10']=key; r['exact_group_id_phase10']=hashlib.sha256(key.encode()).hexdigest()[:16]; r['duplicate_count_phase10']=str(len(items)); out.append(r)
 Path(a.output).parent.mkdir(parents=True,exist_ok=True)
 with open(a.output,'w',encoding='utf-8',newline='') as f: w=csv.DictWriter(f,fieldnames=list(out[0])); w.writeheader(); w.writerows(out)
 audit={'input_rows':len(rows),'unique_normalized_texts':len(out),'duplicate_rows':len(rows)-len(out),'text_column':col}; Path(a.audit).parent.mkdir(parents=True,exist_ok=True); Path(a.audit).write_text(json.dumps(audit,indent=2),encoding='utf-8'); print(audit)
if __name__=='__main__': main()
