"""Audit labels and report values outside the predeclared three-class vocabulary."""
import argparse,csv,json
from collections import Counter
from pathlib import Path
def main():
 p=argparse.ArgumentParser(); p.add_argument('--input',required=True); p.add_argument('--output',required=True); a=p.parse_args()
 with open(a.input,encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
 col=next((x for x in ['Sentiment','sentiment','label'] if rows and x in rows[0]),None)
 if not col: raise SystemExit('No supported label column found')
 counts=Counter((r.get(col) or '').strip().casefold() for r in rows); allowed={'negative','neutral','positive'}; result={'label_column':col,'rows':len(rows),'counts':dict(counts),'unmapped':{k:v for k,v in counts.items() if k not in allowed}}
 Path(a.output).parent.mkdir(parents=True,exist_ok=True); Path(a.output).write_text(json.dumps(result,indent=2),encoding='utf-8'); print(result)
if __name__=='__main__': main()
