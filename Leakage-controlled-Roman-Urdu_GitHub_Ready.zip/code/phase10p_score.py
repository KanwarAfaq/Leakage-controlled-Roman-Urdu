"""Read-only scoring of sealed Phase 10P predictions against protected gold labels."""

from __future__ import annotations

import csv
import hashlib
import json
import math
from collections import Counter
from pathlib import Path

import numpy as np
from scipy.stats import binomtest


ROOT = Path(__file__).resolve().parents[3]
OUT = ROOT / "Evidence/Phase10P_Final_Recovered_Experiment"
SEALED = OUT / "Phase10P_Sealed_Five_Conditions.csv"
GOLD = ROOT / "Research_Data/Phase10I_Frozen_Gold/Phase10I_Gold_Labels_Protected.csv"
LABELS = ("negative", "neutral", "positive")
BOOTSTRAP = 10000
SEED = 20261025


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def norm(value):
    value = "" if value is None else str(value).strip().casefold()
    return value


def read_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def metric(y_true, y_pred):
    correct = [a == b for a, b in zip(y_true, y_pred)]
    accuracy = sum(correct) / len(correct) if correct else 0.0
    fs, rows = [], []
    for label in LABELS:
        tp = sum(a == label and b == label for a, b in zip(y_true, y_pred))
        fp = sum(a != label and b == label for a, b in zip(y_true, y_pred))
        fn = sum(a == label and b != label for a, b in zip(y_true, y_pred))
        precision = tp / (tp + fp) if tp + fp else 0.0
        recall = tp / (tp + fn) if tp + fn else 0.0
        f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
        fs.append(f1)
        rows.append((label, tp, fp, fn, precision, recall, f1))
    return {"accuracy": accuracy, "macro_f1": sum(fs) / len(fs), "per_class": rows}


def confusion(y_true, y_pred):
    return {(a, b): sum(x == a and y == b for x, y in zip(y_true, y_pred)) for a in LABELS for b in LABELS}


def csv_write(path, rows, fields):
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


def main():
    pred = read_csv(SEALED)
    gold = read_csv(GOLD)
    gold_by_id = {r["candidate_id"]: norm(r["final_sentiment"]) for r in gold if norm(r.get("eligibility")) != "excluded"}
    if len(gold_by_id) != 315 or set(gold_by_id.values()) - set(LABELS):
        raise SystemExit("Protected gold set is not 315 eligible three-class records")
    expected = Counter({"negative": 146, "positive": 128, "neutral": 41})
    if Counter(gold_by_id.values()) != expected:
        raise SystemExit(f"Gold class distribution mismatch: {Counter(gold_by_id.values())}")
    conditions = sorted({r["condition"] for r in pred})
    if len(pred) != 1575 or len({(r["record_id"], r["condition"]) for r in pred}) != 1575:
        raise SystemExit("Sealed prediction file is incomplete or duplicated")
    results, per_class_rows, cm_rows, usage_rows = [], [], [], []
    arrays = {}
    for condition in conditions:
        rows = sorted((r for r in pred if r["condition"] == condition), key=lambda r: list(gold_by_id).index(r["record_id"]))
        if len(rows) != 315 or {r["record_id"] for r in rows} != set(gold_by_id):
            raise SystemExit(f"Condition mismatch: {condition}")
        y_true = [gold_by_id[r["record_id"]] for r in rows]
        y_pred = [norm(r.get("parsed_label")) if norm(r.get("valid")) == "true" else "" for r in rows]
        arrays[condition] = {"true": y_true, "pred": y_pred, "correct": np.array([a == b for a, b in zip(y_true, y_pred)], dtype=bool)}
        m = metric(y_true, y_pred)
        valid_idx = [i for i, p in enumerate(y_pred) if p in LABELS]
        valid_m = metric([y_true[i] for i in valid_idx], [y_pred[i] for i in valid_idx]) if valid_idx else {"accuracy": None, "macro_f1": None, "per_class": []}
        invalid = len(y_pred) - len(valid_idx)
        results.append({"condition": condition, "n": 315, "accuracy_all_requests": m["accuracy"], "macro_f1_all_requests": m["macro_f1"], "valid_output_coverage": len(valid_idx) / 315, "invalid_count": invalid, "accuracy_valid_only": valid_m["accuracy"], "macro_f1_valid_only": valid_m["macro_f1"]})
        for scope, mm, support_true in (("all_requests_primary", m, y_true), ("valid_only_secondary", valid_m, [y_true[i] for i in valid_idx])):
            for label, tp, fp, fn, precision, recall, f1 in mm["per_class"]:
                per_class_rows.append({"condition": condition, "scope": scope, "class": label, "support": sum(x == label for x in support_true), "tp": tp, "fp": fp, "fn": fn, "precision": precision, "recall": recall, "f1": f1})
        cm = confusion([y_true[i] for i in valid_idx], [y_pred[i] for i in valid_idx])
        for a in LABELS:
            for b in LABELS:
                cm_rows.append({"condition": condition, "matrix_scope": "valid_parsed_outputs_only", "true_class": a, "predicted_class": b, "count": cm[(a, b)]})
        lat = [float(r["latency_seconds"]) for r in rows if r.get("latency_seconds") not in (None, "", "null")]
        tok = {k: [int(float(r[k])) for r in rows if r.get(k) not in (None, "", "null")] for k in ("prompt_tokens", "completion_tokens", "total_tokens")}
        usage_rows.append({"condition": condition, "requests": len(rows), "valid": len(valid_idx), "invalid": invalid, "mean_latency_seconds": float(np.mean(lat)) if lat else None, "median_latency_seconds": float(np.median(lat)) if lat else None, "mean_prompt_tokens": float(np.mean(tok["prompt_tokens"])) if tok["prompt_tokens"] else None, "mean_completion_tokens": float(np.mean(tok["completion_tokens"])) if tok["completion_tokens"] else None, "mean_total_tokens": float(np.mean(tok["total_tokens"])) if tok["total_tokens"] else None, "status_counts": dict(Counter(r.get("status_code") for r in rows)), "finish_reason_counts": dict(Counter(r.get("finish_reason") for r in rows))})

    # Paired bootstrap intervals and prespecified comparisons are computed on identical IDs.
    rng = np.random.default_rng(SEED)
    boot = {c: {"accuracy": [], "macro_f1": []} for c in conditions}
    for _ in range(BOOTSTRAP):
        idx = rng.integers(0, 315, size=315)
        for c in conditions:
            a = arrays[c]["true"]
            b = arrays[c]["pred"]
            mm = metric([a[i] for i in idx], [b[i] for i in idx])
            boot[c]["accuracy"].append(mm["accuracy"])
            boot[c]["macro_f1"].append(mm["macro_f1"])
    ci_rows, stat_rows = [], []
    for c in conditions:
        for k in ("accuracy", "macro_f1"):
            ci_rows.append({"condition": c, "metric": k, "estimate": next(r[k + "_all_requests"] for r in results if r["condition"] == c), "bootstrap_95_lower": float(np.percentile(boot[c][k], 2.5)), "bootstrap_95_upper": float(np.percentile(boot[c][k], 97.5)), "resamples": BOOTSTRAP, "seed": SEED})
    comparisons = [("tfidf_logistic_regression", c) for c in conditions if c != "tfidf_logistic_regression"]
    comparisons += [("gpt_oss_zero_shot", "gpt_oss_few_shot"), ("gemma_zero_shot", "gemma_few_shot")]
    for a, b in comparisons:
        ca, cb = arrays[a]["correct"], arrays[b]["correct"]
        discord_a = int(np.sum(ca & ~cb)); discord_b = int(np.sum(~ca & cb)); n = discord_a + discord_b
        p = float(binomtest(min(discord_a, discord_b), n=n, p=0.5, alternative="two-sided").pvalue) if n else 1.0
        diffs = []
        for _ in range(BOOTSTRAP):
            idx = rng.integers(0, 315, size=315)
            ma = metric([arrays[a]["true"][i] for i in idx], [arrays[a]["pred"][i] for i in idx])
            mb = metric([arrays[b]["true"][i] for i in idx], [arrays[b]["pred"][i] for i in idx])
            diffs.append(ma["macro_f1"] - mb["macro_f1"])
        stat_rows.append({"comparison": f"{a} vs {b}", "discordant_a_correct_b_incorrect": discord_a, "discordant_a_incorrect_b_correct": discord_b, "mcnemar_exact_p": p, "macro_f1_difference_a_minus_b": next(r["macro_f1_all_requests"] for r in results if r["condition"] == a) - next(r["macro_f1_all_requests"] for r in results if r["condition"] == b), "macro_f1_difference_bootstrap_95_lower": float(np.percentile(diffs, 2.5)), "macro_f1_difference_bootstrap_95_upper": float(np.percentile(diffs, 97.5)), "interpretation": "descriptive unadjusted paired comparison; no universal superiority claim"})

    csv_write(OUT / "Phase10P_Final_Metrics.csv", results, list(results[0].keys()))
    csv_write(OUT / "Phase10P_Per_Class_Results.csv", per_class_rows, list(per_class_rows[0].keys()))
    csv_write(OUT / "Phase10P_Confusion_Matrices.csv", cm_rows, list(cm_rows[0].keys()))
    csv_write(OUT / "Phase10P_Usage_and_Coverage.csv", usage_rows, list(usage_rows[0].keys()))
    payload = {"gold_records": 315, "gold_class_counts": dict(expected), "prediction_file_sha256": sha256(SEALED), "gold_file_sha256": sha256(GOLD), "metrics": results, "bootstrap_confidence_intervals": ci_rows, "paired_comparisons": stat_rows, "policy": "invalid outputs count as incorrect in all-request primary metrics; confusion matrices are valid parsed outputs only; valid-only metrics are secondary", "gold_access_after_seal": True}
    (OUT / "Phase10P_Final_Metrics.json").write_text(json.dumps(payload, indent=2), encoding="utf-8")
    lines = ["# Phase 10P statistical analysis", "", "Gold scoring was performed only after the 1,575-row prediction seal passed. Invalid outputs were counted as incorrect in the primary all-request metrics. Confusion matrices use valid parsed outputs only; valid-only metrics are secondary.", "", "## Bootstrap", f"Paired bootstrap confidence intervals used {BOOTSTRAP:,} resamples of the 315 identical IDs with seed {SEED}. Macro-F1 and accuracy intervals are percentile intervals. Pairwise macro-F1 differences are descriptive.", "", "## Paired accuracy tests", "Exact two-sided McNemar tests were computed for TF-IDF versus each LLM condition and for zero-shot versus few-shot within GPT-OSS and Gemma. These are prespecified descriptive comparisons; no multiplicity-adjusted universal superiority claim is made.", ""]
    for x in stat_rows:
        lines.append(f"- {x['comparison']}: discordances {x['discordant_a_correct_b_incorrect']} vs {x['discordant_a_incorrect_b_correct']}; exact McNemar p={x['mcnemar_exact_p']:.6g}; macro-F1 difference={x['macro_f1_difference_a_minus_b']:.6f} (bootstrap 95% CI {x['macro_f1_difference_bootstrap_95_lower']:.6f}, {x['macro_f1_difference_bootstrap_95_upper']:.6f}).")
    (OUT / "Phase10P_Statistical_Analysis.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    (OUT / "Phase10P_Final_Integrity_and_Research_Audit.md").write_text("# Phase 10P final integrity and research audit\n\nThe concurrent-launch deviation was disclosed before gold access. The first recorded response per key was selected label-blind; all 809 extras were retained separately. The 1,575-row seal passed before protected labels were read. Gold labels were then read by this separate scorer. No API requests, retuning, retries, or post-gold changes occurred. Results must be interpreted as a transparently reconstructed evaluation, not as strict single-attempt execution.\n", encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
