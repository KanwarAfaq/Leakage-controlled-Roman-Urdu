import argparse,csv,json,pickle
from pathlib import Path
def load(p):
    with open(p,encoding='utf-8-sig',newline='') as f: r=list(csv.DictReader(f))
    t=next(x for x in ['Review','review','text','normalized_text'] if x in r[0]); y=next(x for x in ['Sentiment','sentiment','label'] if x in r[0]); return [x[t] for x in r],[(x[y] or '').casefold() for x in r]
def main():
    p=argparse.ArgumentParser(); p.add_argument('--train',required=True); p.add_argument('--validation',required=True); p.add_argument('--output-dir',required=True); a=p.parse_args(); Path(a.output_dir).mkdir(parents=True,exist_ok=True)
    try:
        from sklearn.feature_extraction.text import TfidfVectorizer
        from sklearn.linear_model import LogisticRegression
        from sklearn.metrics import accuracy_score,f1_score
    except ImportError: raise SystemExit('Install requirements.txt before training')
    tx,ty=load(a.train); vx,vy=load(a.validation); vec=TfidfVectorizer(ngram_range=(1,2),sublinear_tf=True,min_df=2); model=LogisticRegression(max_iter=1000,random_state=20261025); model.fit(vec.fit_transform(tx),ty); pred=model.predict(vec.transform(vx)); result={'train_rows':len(tx),'validation_rows':len(vx),'accuracy':accuracy_score(vy,pred),'macro_f1':f1_score(vy,pred,average='macro'),'settings':{'ngram_range':[1,2],'min_df':2,'max_iter':1000,'seed':20261025}}
    Path(a.output_dir,'metrics.json').write_text(json.dumps(result,indent=2),encoding='utf-8'); pickle.dump({'vectorizer':vec,'model':model},open(Path(a.output_dir,'model.pkl'),'wb')); print(result)
if __name__=='__main__': main()
