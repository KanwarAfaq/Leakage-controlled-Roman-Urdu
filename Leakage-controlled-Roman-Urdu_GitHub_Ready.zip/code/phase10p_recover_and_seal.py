"""Recover first-recorded LLM outcomes and seal them with TF-IDF predictions.

This script never opens protected gold labels and makes no API requests.
"""

from __future__ import annotations

import csv
import hashlib
import json
from collections import Counter
from pathlib import Path


ROOT = Path(__file__).resolve().parents[3]
LEDGER = ROOT / "Evidence/Phase10N_Final_Experiment/Phase10N_Final_Request_Ledger.jsonl"
MANIFEST = ROOT / "Research_Data/Phase10I_Frozen_Gold/Phase10I_Label_Free_Test_Manifest.csv"
CONFIG = ROOT / "Reproducibility_Code/Phase10_Expanded_Study/Phase10J_Artifacts/Phase10J_Frozen_Experiment_Configuration.json"
MODEL = ROOT / "Reproducibility_Code/Phase10_Expanded_Study/Phase10J_Artifacts/balanced_strict/tfidf_run/model.pkl"
OUT = ROOT / "Evidence/Phase10P_Final_Recovered_Experiment"
LABELS = {"negative", "neutral", "positive"}
CONDITIONS = ("gpt_oss_zero_shot", "gpt_oss_few_shot", "gemma_zero_shot", "gemma_few_shot")


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def parse_label(value):
    value = "" if value is None else str(value).strip().casefold()
    return value if value in LABELS else None


def render_prompt(condition, config, text):
    p = config["prompts"]
    if condition.endswith("zero_shot"):
        return p["zero_shot_template"].format(text=text)
    demos = "\n".join(f"Example review: {d['text']}\nExample label: {d['label']}" for d in p["demonstrations"])
    return p["few_shot_template"].format(demonstrations=demos, text=text)


def load_csv(path):
    with path.open(encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def csv_write(path, rows, fields):
    with path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    ledger_rows = [json.loads(x) for x in LEDGER.read_text(encoding="utf-8").splitlines() if x.strip()]
    manifest_rows = load_csv(MANIFEST)
    config = json.loads(CONFIG.read_text(encoding="utf-8"))
    unsigned = dict(config)
    config_hash = unsigned.pop("configuration_sha256")
    actual_config_hash = hashlib.sha256(json.dumps(unsigned, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    manifest_hash = sha256(MANIFEST)
    if actual_config_hash != config_hash or manifest_hash != config["label_free_manifest_file_sha256"]:
        raise SystemExit("Frozen configuration or manifest hash mismatch; no seal created")
    manifest_by_id = {r["candidate_id"]: r for r in manifest_rows}
    if len(manifest_rows) != 315 or len(manifest_by_id) != 315:
        raise SystemExit("Frozen manifest is not exactly 315 unique records")
    expected_models = {c["name"]: c["model_identifier"] for c in config["conditions"] if c["name"] != "tfidf_logistic_regression"}
    selected, extras, seen = [], [], set()
    for line_no, row in enumerate(ledger_rows, start=1):
        key = (row.get("record_id"), row.get("condition"), row.get("model"))
        if row.get("condition") not in CONDITIONS or row.get("model") != expected_models.get(row.get("condition")) or row.get("record_id") not in manifest_by_id:
            raise SystemExit(f"Unexpected ledger row at line {line_no}; no seal created")
        expected_prompt_hash = hashlib.sha256(render_prompt(row["condition"], config, manifest_by_id[row["record_id"]]["original_text"]).encode()).hexdigest()
        if row.get("configuration_sha256") != config_hash or row.get("manifest_sha256") != manifest_hash or row.get("prompt_sha256") != expected_prompt_hash:
            raise SystemExit(f"Frozen metadata mismatch at line {line_no}; no seal created")
        out = {
            "ledger_line": line_no,
            "record_id": row["record_id"],
            "condition": row["condition"],
            "model": row["model"],
            "prompt_sha256": row["prompt_sha256"],
            "timestamp_utc": row.get("timestamp_utc"),
            "status_code": row.get("status_code"),
            "finish_reason": row.get("finish_reason"),
            "visible_content": row.get("visible_content"),
            "parsed_label": parse_label(row.get("parsed_label")),
            "valid": parse_label(row.get("parsed_label")) is not None,
            "latency_seconds": row.get("latency_seconds"),
            "prompt_tokens": (row.get("usage") or {}).get("prompt_tokens"),
            "completion_tokens": (row.get("usage") or {}).get("completion_tokens"),
            "total_tokens": (row.get("usage") or {}).get("total_tokens"),
            "error": json.dumps(row.get("error"), ensure_ascii=False),
            "raw_response": json.dumps(row.get("raw_response"), ensure_ascii=False, separators=(",", ":")),
            "selection_rule": "first_recorded_response_per_record_condition_model_key",
        }
        if key in seen:
            extras.append(out)
        else:
            selected.append(out)
            seen.add(key)
    if len(selected) != 1260 or len(extras) != 809:
        raise SystemExit(f"Unexpected recovery counts selected={len(selected)} extras={len(extras)}")
    for condition in CONDITIONS:
        subset = [r for r in selected if r["condition"] == condition]
        if len(subset) != 315 or len({r["record_id"] for r in subset}) != 315:
            raise SystemExit(f"Recovery condition incomplete: {condition}")
    fields = list(selected[0].keys())
    csv_write(OUT / "Phase10P_Recovered_1260_LLM_Predictions.csv", selected, fields)
    csv_write(OUT / "Phase10P_Extra_Attempts_Audit.csv", extras, fields)

    # TF-IDF only uses the frozen label-free manifest and the already fitted artifact.
    import pickle
    with MODEL.open("rb") as f:
        artifact = pickle.load(f)
    tfidf_pred = artifact["model"].predict(artifact["vectorizer"].transform([r["original_text"] for r in manifest_rows]))
    if len(tfidf_pred) != 315:
        raise SystemExit("TF-IDF did not produce exactly 315 predictions")
    tfidf = [{"record_id": r["candidate_id"], "condition": "tfidf_logistic_regression", "model": "development_fitted_artifact", "parsed_label": str(p), "valid": True, "latency_seconds": None, "prompt_tokens": None, "completion_tokens": None, "total_tokens": None, "source": "frozen_balanced_strict_model_artifact"} for r, p in zip(manifest_rows, tfidf_pred)]
    csv_write(OUT / "Phase10P_TFIDF_315_Predictions.csv", tfidf, list(tfidf[0].keys()))
    sealed = tfidf + [{**r, "source": "first_recorded_ledger_response"} for r in selected]
    expected_keys = {(r["record_id"], r["condition"]) for r in sealed}
    if len(sealed) != 1575 or len(expected_keys) != 1575:
        raise SystemExit("Five-condition seal has missing or duplicate keys")
    sealed_fields = ["record_id", "condition", "model", "parsed_label", "valid", "latency_seconds", "prompt_tokens", "completion_tokens", "total_tokens", "source", "ledger_line", "timestamp_utc", "status_code", "finish_reason", "prompt_sha256", "error", "raw_response", "selection_rule"]
    csv_write(OUT / "Phase10P_Sealed_Five_Conditions.csv", sealed, sealed_fields)
    hashes = {name: sha256(OUT / name) for name in ("Phase10P_Recovered_1260_LLM_Predictions.csv", "Phase10P_Extra_Attempts_Audit.csv", "Phase10P_TFIDF_315_Predictions.csv", "Phase10P_Sealed_Five_Conditions.csv")}
    hashes.update({"original_ledger_sha256": sha256(LEDGER), "manifest_sha256": manifest_hash, "configuration_sha256": config_hash, "tfidf_model_sha256": sha256(MODEL), "selection_rule": "first_recorded_response_per_record_condition_model_key", "gold_labels_opened": False})
    (OUT / "Phase10P_Prediction_Hashes.json").write_text(json.dumps(hashes, indent=2), encoding="utf-8")
    report = f"""# Phase 10P deterministic recovery and prediction seal

## Status: PREDICTIONS SEALED — GOLD NOT YET OPENED

The original ledger was preserved unchanged. The researcher reports that two PowerShell windows ran concurrently. The ledger proves 2,069 recorded entries, 1,260 unique record-condition-model keys, and 809 additional recorded attempts. It does not prove request-start ordering; therefore the recovery uses the first recorded response in ledger order for each key. This is not claimed to be the first network request, because concurrent responses may complete out of order.

Selected outcomes: 1,260 LLM rows, 315 per condition. Extra attempts retained separately: 809. TF-IDF predictions: 315. Sealed outcomes: 1,575 unique record-condition rows.

Selection was label-blind and performed before gold access. It did not inspect correctness, labels, or favorable outcomes. Invalid, timeout, transport, truncated, and failed first-recorded responses were retained as invalid. No API request was made and protected labels were not opened.

Files and hashes are recorded in `Phase10P_Prediction_Hashes.json`. The separate scorer may open protected labels only after this seal.
"""
    (OUT / "Phase10P_Deterministic_Recovery_Method.md").write_text(report, encoding="utf-8")
    print(json.dumps({"status": "SEALED_BEFORE_GOLD_ACCESS", "selected_llm": len(selected), "extra_attempts": len(extras), "tfidf": len(tfidf), "sealed": len(sealed), "gold_opened": False}, indent=2))


if __name__ == "__main__":
    main()
