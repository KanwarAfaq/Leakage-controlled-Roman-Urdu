import argparse,csv,hashlib,json
from pathlib import Path
def main():
    p=argparse.ArgumentParser(); p.add_argument('--input',required=True); p.add_argument('--output',required=True); p.add_argument('--n-demonstrations',type=int,default=6); a=p.parse_args()
    with open(a.input,encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
    t=next(x for x in ['Review','review','text','normalized_text'] if x in rows[0]); y=next(x for x in ['Sentiment','sentiment','label'] if x in rows[0]); demos=[]
    for r in rows:
        if (r.get(y) or '').casefold() in {'negative','neutral','positive'}: demos.append({'id':r.get('source_row_id',''),'text':r[t],'label':r[y].casefold()})
        if len(demos)>=a.n_demonstrations: break
    result={'seed':20261025,'demonstrations':demos,'parser_allowed':['negative','neutral','positive'],'invalid_policy':'preserve and count as incorrect in all-request metrics'}; result['demonstration_sha256']=hashlib.sha256(json.dumps(demos,sort_keys=True,ensure_ascii=False).encode()).hexdigest(); Path(a.output).parent.mkdir(parents=True,exist_ok=True); Path(a.output).write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8'); print({'demonstrations':len(demos),'sha256':result['demonstration_sha256']})
if __name__=='__main__': main()
