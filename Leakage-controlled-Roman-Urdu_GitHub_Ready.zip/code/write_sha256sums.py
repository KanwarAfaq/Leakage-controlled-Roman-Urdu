"""Write deterministic SHA-256 sums for all release files except the sums file."""
from pathlib import Path
import hashlib

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "SHA256SUMS.txt"
rows = []
for path in sorted(ROOT.rglob("*")):
    if not path.is_file() or path == OUT or ".git" in path.parts:
        continue
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    rows.append(f"{digest}  {path.relative_to(ROOT).as_posix()}")
OUT.write_text("\n".join(rows) + "\n", encoding="utf-8")
print(f"wrote {len(rows)} file checksums")
