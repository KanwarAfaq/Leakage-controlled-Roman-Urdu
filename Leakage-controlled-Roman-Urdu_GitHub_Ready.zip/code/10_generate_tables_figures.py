import argparse,json
from pathlib import Path
def main():
    p=argparse.ArgumentParser(); p.add_argument('--metrics',required=True); p.add_argument('--output-dir',required=True); a=p.parse_args(); x=json.loads(Path(a.metrics).read_text(encoding='utf-8')); Path(a.output_dir).mkdir(parents=True,exist_ok=True); Path(a.output_dir,'metrics.json').write_text(json.dumps(x,indent=2),encoding='utf-8'); Path(a.output_dir,'README.md').write_text('Generated only from the supplied metrics JSON; no new results were calculated.\n',encoding='utf-8'); print('outputs written')
if __name__=='__main__': main()
