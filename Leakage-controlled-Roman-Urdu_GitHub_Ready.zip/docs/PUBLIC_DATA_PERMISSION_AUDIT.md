# Public data permission audit

Status: **Researcher permission confirmed; source-specific license verification remains an explicit release gate.**

Kanwar Muhammad Afaq confirmed permission to publish the study dataset. This confirmation is recorded as author-provided evidence and is not represented as independent verification of every upstream source license, platform term, or privacy condition. The release includes the 315-record human-gold CSV because that permission was supplied for this release; the fields are limited to the approved text, final labels, identifiers, hashes, and eligibility status. Reviewer workbooks, adjudication notes, raw request bodies, credentials, and private logs remain excluded.

Before public upload, the authors must obtain or verify, for each source family:

1. original dataset license and derivative-data terms;
2. whether review text may be redistributed in a research repository;
3. whether human labels may be redistributed with text or only under controlled access;
4. privacy, platform, and institutional restrictions;
5. whether raw model logs or reasoning may be released.

The public CSV should be removed or converted to an access-controlled release if any source-specific permission, privacy review, or provider term does not permit redistribution. Do not add reviewer files, raw logs, or credentials.
