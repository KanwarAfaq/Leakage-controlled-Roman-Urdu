# Data dictionary

## Public metadata and results

- `candidate_id`: frozen record identifier; does not include review text.
- `text_sha256`: SHA-256 of the withheld original text.
- `record_id`: record identifier in the prediction result.
- `condition`: one of the five frozen experimental conditions.
- `model`: model or local artifact identifier.
- `parsed_label`: parser output when valid; blank for invalid outcomes.
- `valid`: strict parser validity flag.
- `latency_seconds`: recorded request latency when available.
- `prompt_tokens`, `completion_tokens`, `total_tokens`: non-secret usage metadata when available.
- `invalid_count`: number of invalid outputs for a condition.

## Withheld fields

Original review text, protected final labels, raw request/response bodies, reasoning, private annotations, signatures, credentials, and reviewer identity records are withheld.
