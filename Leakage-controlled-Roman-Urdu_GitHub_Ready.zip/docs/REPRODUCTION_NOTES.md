# Reproduction notes

The aggregate Phase 10P results are preserved in `results/`. The original final experiment used a CGU-hosted local-model endpoint and four LLM conditions. Equivalent institutional access is required for a fresh inference run; this release does not authorize or perform API calls.

The original ledger recorded 2,069 attempts for 1,260 unique condition keys because two PowerShell windows were launched concurrently. The selected outcome was the first recorded response per key, not a gold-guided or best-response selection. All 809 additional attempts remain outside this public release because raw response bodies and reasoning may contain review text and sensitive metadata.

Primary metrics count invalid outputs as incorrect. Confusion matrices contain valid parsed outputs only. Bootstrap intervals use 10,000 paired resamples with seed 20261025; paired accuracy comparisons use the prespecified exact McNemar procedure.

The chronology record must be reconciled before publication because an earlier hash manifest records `gold_labels_opened: false`, while final scoring evidence records gold access after sealing.
